package com.example.portfolio_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
